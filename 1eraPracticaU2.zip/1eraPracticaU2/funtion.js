
const gridECS = document.querySelector('.ECS-grid');
const botonECS = document.querySelector('.ECS-boton');

botonECS.addEventListener('click', () => {
    const coloresAlternos = gridECS.classList.toggle('ECS-grid--alternar');
    botonECS.setAttribute('aria-pressed', String(coloresAlternos));
});
